from pandas import read_excel;

df = read_excel(
    'D://PDA//4.1//3.xlsx', 
    sheetname='data'
)
