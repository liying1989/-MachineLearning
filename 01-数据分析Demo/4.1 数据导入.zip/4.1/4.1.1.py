#http://www.datastudy.cc/article/eb1606d2398f840ad9ff8be7fb6baffd

from pandas import read_csv

df = read_csv(
    'D://PDA//4.1//1.csv'
)
df